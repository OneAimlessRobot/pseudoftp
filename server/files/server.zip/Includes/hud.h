#ifndef HUD_H
#define HUD_H
void printServerState(void);
void printServerLogs(void);
void printClientsOfState(char buff[LOGMSGLENGTH*20]);
void printAdminsOfState(char buff[LOGMSGLENGTH*20]);
#endif
