#ifndef INFOMETERS_H
#define INFOMETERS_H
void* graphicsLoop(void* params);


void* serverLogWritting(void* params);

void pushLog(char* log);

void* updateRates(void* arg);

#endif
