#ifndef COMPARATOR_H
#define COMPARATOR_H

typedef struct comparator{

int (*func)(void*,void*);


}comparator;


#endif
