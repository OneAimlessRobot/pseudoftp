#ifndef ACCOUNTS_H
#define ACCOUNTS_H


void loadLogins();

void saveLogins();
#endif
